package policyhandler

// func TestGetPoliciesFromBackend(t *testing.T) {
// 	notification := reporthandling.PolicyNotification{
// 		Rules: []reporthandling.PolicyIdentifier{
// 			{
// 				Kind: reporthandling.KindFramework,
// 				Name: "mitretest",
// 			},
// 		},
// 	}
// 	// os.Setenv(cacli., "")
// 	ph := PolicyHandler{
// 		cacli: &cacli.Cacli{},
// 	}
// 	f, err := ph.GetPoliciesFromBackend(&notification)
// 	if err != nil {
// 		t.Error(err)
// 	}
// 	if len(f) == 0 {
// 		t.Errorf("empty")
// 	}
// }
