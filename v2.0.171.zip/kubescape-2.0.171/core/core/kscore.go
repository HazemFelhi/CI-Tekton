package core

type Kubescape struct{}

func NewKubescape() *Kubescape {
	return &Kubescape{}
}
