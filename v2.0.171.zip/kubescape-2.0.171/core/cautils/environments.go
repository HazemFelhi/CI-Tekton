package cautils

// Kubescape Cloud environment vars
var (
	CustomerGUID = ""
	ClusterName  = ""
)
